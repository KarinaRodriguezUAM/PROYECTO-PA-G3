# UAM Lab Help Desk — Requerimiento 1

Sistema de gestión de laboratorios y equipos universitarios.

---

## Stack Tecnológico

| Capa | Tecnología |
|------|-----------|
| Backend API | .NET 10 — ASP.NET Core Web API |
| Frontend | ASP.NET Core MVC |
| ORM | Entity Framework Core 10 |
| Base de datos | SQL Server (SQLEXPRESS) |
| Autenticación | JWT (configurado, sin login visual) |
| Documentación | Swagger / OpenAPI |

---

## Estructura del Proyecto

```
UamLabHelpDesk/
├── Api/                          ← ASP.NET Core Web API
│   ├── Controllers/
│   │   ├── AuthController.cs
│   │   ├── LaboratoriesController.cs
│   │   └── EquipmentController.cs
│   ├── Data/
│   │   ├── AppDbContext.cs
│   │   ├── AppDbContextFactory.cs
│   │   └── Migrations/
│   ├── DTOs/
│   │   ├── ApiOperationResultDto.cs
│   │   ├── AuthDtos.cs
│   │   ├── LaboratoryDtos.cs
│   │   └── EquipmentDtos.cs
│   ├── Interfaces/
│   │   ├── IRepository.cs
│   │   ├── ILaboratoryRepository.cs
│   │   ├── IEquipmentRepository.cs
│   │   └── IUnitOfWork.cs
│   ├── Middlewares/
│   │   └── ExceptionMiddleware.cs
│   ├── Models/
│   │   ├── Laboratory.cs
│   │   └── Equipment.cs
│   ├── Repositories/
│   │   ├── Repository.cs
│   │   ├── LaboratoryRepository.cs
│   │   ├── EquipmentRepository.cs
│   │   └── UnitOfWork.cs
│   ├── Resources/
│   │   ├── Controllers/
│   │   │   ├── LaboratoriesController.resx
│   │   │   ├── LaboratoriesController.en.resx
│   │   │   ├── EquipmentController.resx
│   │   │   └── EquipmentController.en.resx
│   │   └── Repositories/
│   │       ├── LaboratoryRepository.resx
│   │       ├── LaboratoryRepository.en.resx
│   │       ├── EquipmentRepository.resx
│   │       └── EquipmentRepository.en.resx
│   ├── appsettings.json
│   ├── Program.cs
│   └── Uam.LabHelpDesk.Api.slnx
│
├── MvcClient/                    ← ASP.NET Core MVC
│   ├── Controllers/
│   │   ├── LaboratoriesController.cs
│   │   └── EquipmentController.cs
│   ├── Models/
│   │   └── ApiModels.cs
│   ├── Views/
│   │   ├── Laboratories/Index.cshtml
│   │   ├── Equipment/Index.cshtml
│   │   └── Shared/_Layout.cshtml
│   ├── appsettings.json
│   ├── Program.cs
│   └── Uam.LabHelpDesk.MvcClient.slnx
│
└── UamLabHelpDeskDb_CreateScript.sql
```

---

## Pasos para ejecutar

### 1. Crear la base de datos

**Opción A — Script SQL (recomendado):**

1. Abrir SQL Server Management Studio.
2. Conectarse a `.\SQLEXPRESS`.
3. Abrir y ejecutar `UamLabHelpDeskDb_CreateScript.sql`.

Esto crea la base de datos, las tablas y datos de ejemplo, y registra la migración en `__EFMigrationsHistory`.

**Opción B — EF Core migrations:**

```bash
cd Api
dotnet ef database update
```

### 2. Configurar cadena de conexión (si es necesario)

Editar `Api/appsettings.json`:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=.\\SQLEXPRESS;Database=UamLabHelpDeskDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true"
}
```

Ajustar `Server=` si la instancia es diferente (ej. `Server=localhost`).

### 3. Ejecutar el API

```bash
cd Api
dotnet run
```

La API queda disponible en: `https://localhost:44333`  
Swagger UI: `https://localhost:44333/swagger`

### 4. Ejecutar el cliente MVC

```bash
cd MvcClient
dotnet run
```

Cliente disponible en: `https://localhost:44334`

---

## Probar en Swagger

### Paso 1 — Obtener token JWT

`POST /api/Auth/Login`

```json
{
  "username": "admin",
  "password": "Admin123!"
}
```

Copiar el valor de `accessToken`.

### Paso 2 — Autorizar en Swagger

Clic en el botón **Authorize** (candado).  
Ingresar: `Bearer <token_copiado>`

### Paso 3 — Probar endpoints

#### Laboratorios

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/Laboratories/GetAllLaboratories` | Lista todos los laboratorios |
| GET | `/api/Laboratories/GetLaboratoryById/{id}` | Obtiene un laboratorio por ID |
| POST | `/api/Laboratories/CreateLaboratory` | Crea un laboratorio |
| PUT | `/api/Laboratories/UpdateLaboratory/{id}` | Actualiza un laboratorio |
| DELETE | `/api/Laboratories/DeleteLaboratory/{id}` | Eliminación lógica |

**Crear laboratorio (body):**
```json
{
  "name": "Laboratorio de Ciberseguridad",
  "building": "Edificio C",
  "floor": 4,
  "capacity": 20
}
```

#### Equipos

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/Equipment/GetAllEquipment` | Lista todos los equipos |
| GET | `/api/Equipment/GetEquipmentById/{id}` | Obtiene un equipo por ID |
| GET | `/api/Equipment/GetEquipmentByLaboratory/{laboratoryId}` | Equipos de un laboratorio |
| POST | `/api/Equipment/CreateEquipment` | Crea un equipo |
| PUT | `/api/Equipment/UpdateEquipment/{id}` | Actualiza un equipo |
| DELETE | `/api/Equipment/DeleteEquipment/{id}` | Eliminación lógica |

**Crear equipo (body):**
```json
{
  "laboratoryId": 1,
  "code": "EQ-010",
  "brand": "Dell",
  "model": "Latitude 5520",
  "serialNumber": "SN-DELL-010",
  "type": "Laptop",
  "status": "Operational",
  "purchaseDate": "2024-01-15"
}
```

Valores válidos para `type`: `Desktop`, `Laptop`, `Printer`, `Projector`, `Other`  
Valores válidos para `status`: `Operational`, `UnderRepair`, `Decommissioned`

---

## Reglas de negocio verificadas

- ✅ `Name` de laboratorio es único — devuelve `Success: false` si está duplicado.
- ✅ `Code` y `SerialNumber` de equipo son únicos.
- ✅ No se puede asignar un equipo a un laboratorio inactivo.
- ✅ Eliminación siempre es lógica (`IsActive = false`).
- ✅ Los registros permanecen en base de datos después de "eliminar".
- ✅ `CreatedAtUtc` y `UpdatedAtUtc` se asignan en el repositorio con `DateTime.UtcNow`.
- ✅ Sin strings hardcodeados — todos los mensajes están en archivos `.resx`.
- ✅ Sin lógica de negocio en los controladores.
- ✅ El cliente MVC consume el API; nunca accede a la DB directamente.
